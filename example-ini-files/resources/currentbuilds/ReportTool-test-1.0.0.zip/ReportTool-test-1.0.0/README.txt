ReportTool test payload for BuildAdder currentbuilds validation.
This is a non-production sample archive.
