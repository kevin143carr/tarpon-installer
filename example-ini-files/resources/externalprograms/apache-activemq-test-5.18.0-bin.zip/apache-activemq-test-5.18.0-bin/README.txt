ActiveMQ-style external program test payload for BuildAdder externalprograms validation.
This is a non-production sample archive.
